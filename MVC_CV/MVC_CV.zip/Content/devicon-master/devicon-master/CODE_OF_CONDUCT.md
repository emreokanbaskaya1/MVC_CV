# The Code of Conduct has been moved to the official [Wiki page](https://github.com/devicons/devicon/wiki/Code-of-Conduct).
