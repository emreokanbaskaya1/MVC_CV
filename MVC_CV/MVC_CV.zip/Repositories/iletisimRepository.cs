﻿using MVC_CV.Models.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_CV.Repositories
{
    public class iletisimRepository : GenericRepository<Tbliletisim>
    {
    }
}